var config = require('./config.global');

config.env = 'dev';

module.exports = config;
