var config = module.exports = {};

config.env = 'dev';
